#!/bin/sh
cd /app && python3 run.py