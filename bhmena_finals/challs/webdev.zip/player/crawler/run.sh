#!/bin/sh
echo started
xvfb-run --auto-servernum node /app/crawler.js