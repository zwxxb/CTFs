module.exports = [
  {
    name: 'Sakura',
    id: 'sakura'
  },
  {
    name: 'Earthly',
    id: 'sakura-earthly'
  },
  {
    name: 'Vader',
    id: 'sakura-vader'
  },
  {
    name: 'Dark Solarized',
    id: 'sakura-dark-solarized'
  },
  {
    name: 'Ink',
    id: 'sakura-ink'
  },
  {
    name: 'Pink',
    id: 'sakura-pink'
  },
  {
    name: 'Radical',
    id: 'sakura-radical'
  }
];
